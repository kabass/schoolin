(function() {
  'use strict';

  var module = angular.module('singApp.components.holderjs', [
  ]);

})();
