(function() {
  'use strict';

    dashboardController.$inject = ['$scope'];
    function dashboardController ($scope) {

    }

  angular.module('singApp.dashboard')
    .controller('DashboardController', dashboardController);

})();
