(function() {
    'use strict';

    angular.module('singApp', [
        'singApp.core',
        'singApp.dashboard',
        'singApp.another',
        'singApp.login',
        'singApp.error'
    ]);
})();
