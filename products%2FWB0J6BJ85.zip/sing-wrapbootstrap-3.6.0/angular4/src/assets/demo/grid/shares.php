<?php sleep(2) ?>
<div class="list-group list-group-lg">
    <a href="#" class="list-group-item animated fadeInDown bg-warning-light">
        <span class="thumb-sm float-xs-left mr">
            <img class="rounded-circle" src="assets/img/people/a6.jpg" alt="...">
        </span>
        <i class="fa fa-circle float-xs-right text-success mt-sm"></i>
        <h6 class="no-margin"><strong>Jenny Wilington</strong></h6>
        <small>just now</small>
    </a>
    <a href="#" class="list-group-item">
        <span class="thumb-sm float-xs-left mr">
            <img class="rounded-circle" src="assets/img/people/a1.jpg" alt="...">
        </span>
        <i class="fa fa-circle float-xs-right text-danger mt-sm"></i>
        <h6 class="no-margin">Maikel Basso</h6>
        <small class="text-muted">about 2 mins ago</small>
    </a>
    <a href="#" class="list-group-item">
        <span class="thumb-sm float-xs-left mr">
            <img class="rounded-circle" src="assets/img/people/a2.jpg" alt="...">
        </span>
        <i class="fa fa-circle float-xs-right text-info mt-sm"></i>
        <h6 class="no-margin">Ianus Arendse</h6>
        <small class="text-muted">about 42 mins ago</small>
    </a>
    <a href="#" class="list-group-item">
        <span class="thumb-sm float-xs-left mr">
            <img class="rounded-circle" src="assets/img/people/a3.jpg" alt="...">
        </span>
        <i class="fa fa-circle float-xs-right text-success mt-sm"></i>
        <h6 class="no-margin">Valdemar Landau</h6>
        <small class="text-muted">one hour ago</small>
    </a>
    <a href="#" class="list-group-item mb-n-md">
        <span class="thumb-sm float-xs-left mr">
            <img class="rounded-circle" src="assets/img/people/a4.jpg" alt="...">
        </span>
        <i class="fa fa-circle float-xs-right text-warning mt-sm"></i>
        <h6 class="no-margin">Rick Teagan</h6>
        <small class="text-muted">3 hours ago</small>
    </a>
</div>
