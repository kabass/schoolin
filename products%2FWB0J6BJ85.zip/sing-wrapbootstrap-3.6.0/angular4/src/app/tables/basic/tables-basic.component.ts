import { Component } from '@angular/core';

@Component({
  selector: '[tables-basic]',
  template: require('./tables-basic.template.html')
})
export class TablesBasic {
}
