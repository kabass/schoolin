import { NgModule }      from '@angular/core';

import 'd3';

@NgModule({
})
export class D3Module {
}
