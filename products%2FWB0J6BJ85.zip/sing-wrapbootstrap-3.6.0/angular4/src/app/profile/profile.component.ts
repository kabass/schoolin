import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: '[profile]',
  templateUrl: './profile.template.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./profile.style.scss']
})
export class Profile {
}
